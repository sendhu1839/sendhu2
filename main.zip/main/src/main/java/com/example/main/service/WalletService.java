package com.example.main.service;


import com.example.main.DTO.Wallet;
import com.example.main.Exceptionshandling.WalletException;

public interface WalletService {
    Wallet registerWallet(Wallet newWallet) throws WalletException;
    Boolean login(Integer walletId,String password)throws WalletException;

    Double addFundsToWallet(Integer walletId, Double amount)throws WalletException;

    Double showWalletBalance(Integer walletId)throws WalletException;

    Boolean fundTransfer(Integer fromId, Integer toId, Double amount)throws WalletException;

    void  unRegisterWallet(Integer walletId,String password)throws WalletException;
}
