package com.example.main.service;

import com.example.main.DAO.WalletDao;
import com.example.main.DAO.WalletDaoImpl;
import com.example.main.DTO.Wallet;
import com.example.main.Exceptionshandling.WalletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public class WalletServiceImpl implements WalletService{


    private WalletDao walletRepository=new WalletDaoImpl();

    @Override
    public Wallet registerWallet(Wallet newWallet) throws WalletException {
       Integer check=0;


        for(Wallet m : this.walletRepository.getAllDetilas().values())
        {
            if(m.getId().compareTo(newWallet.getId())==1)
            {
                check=1;
            }
        }
     if(check==0)
     {
         return this.walletRepository.addWallet(newWallet);
     }
     else
     {
         throw new WalletException("already registred user");
     }
    }

    @Override
    public Boolean login(Integer walletId, String password) throws WalletException {

           if(walletRepository.getWalletById(walletId).getPassword()==password)
           {
               return true;
           }

            else

           {
               throw new WalletException("the password or id is incorrect");
           }
        }

    @Override
    public Double addFundsToWallet(Integer walletId, Double amount) throws WalletException {
        if(this.walletRepository.getWalletById(walletId).getId()!=null) {
            Double currentBalance = this.walletRepository.getWalletById(walletId).getBalance();
            this.walletRepository.getWalletById(walletId).setBalance(currentBalance + amount);
            return walletRepository.getWalletById(walletId).getBalance();
        }
        else
        {
            throw new WalletException("invalid wallet id");
        }
    }

    @Override
    public Double showWalletBalance(Integer walletId) throws WalletException {
          if(this.walletRepository.getWalletById(walletId).getId()!=null) {
              return this.walletRepository.getWalletById(walletId).getBalance();
          }
          else
              throw new WalletException("incorreect wallet id");

    }

    @Override
    public Boolean fundTransfer(Integer fromId, Integer toId, Double amount) throws WalletException {
        if(this.walletRepository.getWalletById(fromId).getBalance()-amount<0) {
            Double senderBalance = this.walletRepository.getWalletById(fromId).getBalance();
            Double receiverBalance = this.walletRepository.getWalletById(toId).getBalance();
            this.walletRepository.getWalletById(toId).setBalance(receiverBalance + amount);
            this.walletRepository.getWalletById(fromId).setBalance(senderBalance - amount);

            return true;
        }
        else
            throw new WalletException("insufficient funds");
    }

    @Override
    public void unRegisterWallet(Integer walletId, String password) throws WalletException {
        if(this.walletRepository.getWalletById(walletId).getPassword()==password)
        {
                this.walletRepository.deleteWalletById(walletId);
            System.out.println("succeessfully unregistered");
            }
            else
                throw new WalletException("Passward incorrect");

    }
}

