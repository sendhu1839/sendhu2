package com.example.main.DAO;


import com.example.main.DTO.Wallet;
import com.example.main.Exceptionshandling.WalletException;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

public class WalletDaoImpl implements WalletDao{

    Map<Integer, Wallet> wallets=new HashMap<>();

    @Override
    public Wallet addWallet(Wallet newWallet) throws WalletException {
        return wallets.put(newWallet.getId(),newWallet);
    }

    @Override
    public Wallet getWalletById(Integer walletId) throws WalletException {
         Wallet details=null;
        for(Wallet m : wallets.values()) {
            if (m.getId() == walletId) {
               details=m;
            }
        }
        return details;
    }

    @Override
    public void  updateWallet(Wallet updateWallet) throws WalletException {
        for(Wallet m : wallets.values())
        {
            if(m.getId()==updateWallet.getId())
            {
                wallets.put(m.getId(),m);
            }
        }


    }

    @Override
    public void  deleteWalletById(Integer walletID) throws WalletException {
        for(Wallet m : wallets.values())
        {
            if(m.getId()==walletID) {

                wallets.remove(walletID);

            }
            }
    }

    @Override
    public Map<Integer,Wallet> getAllDetilas()
    {
        return wallets;
    }
}
