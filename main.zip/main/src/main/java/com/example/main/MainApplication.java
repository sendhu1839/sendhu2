package com.example.main;

import com.example.main.DTO.Wallet;
import com.example.main.controller.WalletContoller;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class MainApplication {

    public static void main(String[] args) {
       WalletContoller walletContoller=new WalletContoller();
              Integer id;
              String name;
              String password;
              Double amount;
              Double balance;
        System.out.println("Welcome to new Wallet Application \n" +
                "1.createwallet \n" +"2.add amount \n" +"3.Login \n" +"4.ShowBalance \n" + "5.sendMoney \n" + "6.DeleteWallet");
        System.out.println("select one of below options");
        Scanner sc=new Scanner(System.in);

        int i=sc.nextInt();
         switch (i)
         {
             case 1:
                 System.out.println("Enter id");
                 id= sc.nextInt();
                 System.out.println("Enter name");
                 name=sc.next();
                 System.out.println("Enter amount");
                 amount= sc.nextDouble();
                 System.out.println("Enter password");
                 password=sc.next();

                 walletContoller.CreateWallet(new Wallet(id,name,amount,password));
                   break;
             case 2:
                 System.out.println("Enter id");
                 id=sc.nextInt();
                 System.out.println("Enter amount");
                 amount=sc.nextDouble();
                 walletContoller.AddAmount(id,amount);
                 break;
             case 3:
                 System.out.println("Enter id");
                 id=sc.nextInt();
                 System.out.println("Enter password");
                 password=sc.next();
                 walletContoller.Login(id,password);
                 break;
             case 4:
                 System.out.println("Enter id");
                 id=sc.nextInt();
                 walletContoller.ShowBalance(id);
                 break;
             case 5:
                 System.out.println("enter senders id");
                 id= sc.nextInt();
                 System.out.println("enter receivers id");
                 Integer id2= sc.nextInt();
                 System.out.println("enter amount");
                 amount= sc.nextDouble();
                 walletContoller.SendMoney(id,id2,amount);
                    break;
             case 6:
                 System.out.println("enter id");
                 id= sc.nextInt();
                 System.out.println("enter password");
                 password=sc.next();
                 walletContoller.DeleteWallet(id,password);

                        break;



         }
    }

}
