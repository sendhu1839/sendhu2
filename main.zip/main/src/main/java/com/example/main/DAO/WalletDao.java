package com.example.main.DAO;


import com.example.main.DTO.Wallet;
import com.example.main.Exceptionshandling.WalletException;

import java.util.Map;

public interface WalletDao {

    Wallet addWallet(Wallet newWallet)throws WalletException;
    Wallet getWalletById(Integer walletId)throws WalletException;
    void  updateWallet(Wallet updateWallet)throws WalletException;
    void deleteWalletById(Integer walletID)throws WalletException;
    Map<Integer,Wallet> getAllDetilas() throws  WalletException;
}
