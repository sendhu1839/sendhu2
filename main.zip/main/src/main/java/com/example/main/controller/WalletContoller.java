package com.example.main.controller;

import com.example.main.DTO.Wallet;
import com.example.main.Exceptionshandling.WalletException;
import com.example.main.service.WalletService;
import com.example.main.service.WalletServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


public class WalletContoller {


        WalletService walletService=new WalletServiceImpl();

        public void CreateWallet(Wallet wallet) {
            try {
                walletService.registerWallet(wallet);
                System.out.println("wallet created sucessfully");

            } catch (WalletException e) {
                System.out.println(e.getMessage());
            }

        }

        public void AddAmount(Integer id,Double amount) {
            try {

                walletService.addFundsToWallet(id,amount);
                System.out.println("amount added sucessfully");
            } catch (WalletException e) {
                System.out.println(e.getMessage());
            }

        }
        public void Login(int id,String password) {
            try {
                walletService.login(id, password);
                System.out.println("sucessfully logged in");
            } catch (WalletException e) {
                System.out.println(e.getMessage());
            }

        }
        public void ShowBalance(Integer id) {

            try {
                Double balance = walletService.showWalletBalance(id);
                System.out.println("your balance is" + balance);
            } catch (WalletException e) {
                System.out.println(e.getMessage());
            }

        }
        public void DeleteWallet(Integer id,String password) {
            try {
                walletService.unRegisterWallet(id, password);
                System.out.println("wallet deleted sucessfully");
            } catch (WalletException e) {
                System.out.println(e.getMessage());
            }
        }

        public void SendMoney(Integer id,Integer id2,Double amount) {
            try {
                walletService.fundTransfer(id, id2, amount);
            } catch (WalletException e) {
                System.out.println(e.getMessage());
            }
        }
}


