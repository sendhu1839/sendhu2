package com.wallet.app.exception;

public class WalletException extends Exception{
    public WalletException(String msg)
    {
        super(msg);
    }
}



